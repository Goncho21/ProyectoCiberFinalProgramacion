﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConsultorioMedico2.Data;
using ConsultorioMedico2.Models;

namespace Consultorio.Desktop
{
    public partial class Form4 : Form
    {

        public Form4()
        {
            InitializeComponent();
            CargarDoctores();
            CargarPacientes();
        }

        private void CargarDoctores()
        {

            try
            {
                using var db = new NuevoConsultorioDBcontext();
                var doctores = db.Doctores.ToList();
                comboBox1.DataSource = doctores;

                comboBox1.DataSource = doctores;
                comboBox1.DisplayMember = "Nombre";
                comboBox1.ValueMember = "Id";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los datos: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void CargarPacientes()
        {

            try
            {
                using var db = new NuevoConsultorioDBcontext();
                var pacientes = db.Pacientes.ToList();
                comboBox2.DataSource = pacientes;

                comboBox2.DataSource = pacientes;
                comboBox2.DisplayMember = "Nombre";
                comboBox2.ValueMember = "Id";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los datos: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var doctor = comboBox1.SelectedItem as Doctores;
            var paciente = comboBox2.SelectedItem as Paciente;
            var fecha = dateTimePicker1.Value.ToString("dddd, dd 'de' MMMM 'de' yyyy");

            if (doctor != null && paciente != null)
            {
                string mensaje = $"Doctor {doctor.Nombre} atenderá a {paciente.Nombre} en la fecha de {fecha}.";
                MessageBox.Show(mensaje, "Turno asignado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Por favor seleccione un doctor y un paciente.", "Datos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
