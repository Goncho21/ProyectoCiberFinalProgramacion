﻿using ConsultorioMedico2.Data;
using ConsultorioMedico2.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Consultorio.Desktop
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            CargarDatos();
        }

        private void CargarDatos()
        {

            try
            {
                using var db = new NuevoConsultorioDBcontext();
                //cargaara la lista de los paciente desde la base de datos
                var doctores = db.Doctores.ToList();
                dataGridView1.DataSource = doctores;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los datos: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if
              (string.IsNullOrWhiteSpace(textBox2.Text) ||
              string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("Por favor, complete todos los campos.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using var db = new NuevoConsultorioDBcontext();
            var doctores = new Doctores
            {
                Nombre = textBox2.Text.Trim(),
                Especialidad = textBox3.Text.Trim(),
            };

            db.Doctores.Add(doctores);
            db.SaveChanges();

            MessageBox.Show("Doctor agregado exitosamente.", "Éxito",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            LimpiarCampos();
            CargarDatos();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Id"]?.Value?.ToString() ?? "";
                textBox2.Text = row.Cells["Nombre"]?.Value?.ToString() ?? "";
                textBox3.Text = row.Cells["Profecion"]?.Value?.ToString() ?? "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Por favor, seleccione un Doctor a actualizar.", "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (string.IsNullOrWhiteSpace(textBox2.Text) ||
                    string.IsNullOrWhiteSpace(textBox3.Text))
                {
                    MessageBox.Show("Por favor, complete todos los campos.", "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(textBox1.Text, out int id))
                {
                    MessageBox.Show("ID debe ser de números válidos.", "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using var db = new ConsultorioDBcontext();
                var doctor = db.Doctores.Find(id);

                if (doctor != null)
                {
                    doctor.Nombre = textBox2.Text.Trim();
                    doctor.Especialidad = textBox3.Text.Trim();

                    db.SaveChanges();

                    MessageBox.Show("DOctor actualizado exitosamente.", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    LimpiarCampos();
                    CargarDatos();
                }
                else
                {
                    MessageBox.Show("No se encontró al Doctor con el ID especificado.", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al actualizar al Doctor: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Por favor, seleccione a un Doctor para eliminar.", "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(textBox1.Text, out int id))
                {
                    MessageBox.Show("ID debe ser un número válido.", "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var resultado = MessageBox.Show("¿Está seguro de que desea eliminar la informacion de este Doctor?",
                    "Confirmar Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    using var db = new NuevoConsultorioDBcontext();
                    var doctor = db.Doctores.Find(id);

                    if (doctor != null)
                    {
                        db.Doctores.Remove(doctor);
                        db.SaveChanges();

                        MessageBox.Show("Doctor eliminado exitosamente.", "Éxito",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);

                        LimpiarCampos();
                        CargarDatos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró el Doctor con el ID especificado.", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar al Doctor: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void LimpiarCampos()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
